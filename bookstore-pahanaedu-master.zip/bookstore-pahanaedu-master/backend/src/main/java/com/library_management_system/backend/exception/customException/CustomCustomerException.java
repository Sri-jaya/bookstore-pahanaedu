package com.library_management_system.backend.exception.customException;

public class CustomCustomerException extends RuntimeException{
    public CustomCustomerException(String message) {
        super(message);
    }

}
