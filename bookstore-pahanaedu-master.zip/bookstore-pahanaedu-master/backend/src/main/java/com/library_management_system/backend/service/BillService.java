package com.library_management_system.backend.service;

import com.library_management_system.backend.dto.BillDTO;
import com.library_management_system.backend.entity.Bill;

public interface BillService {

    Bill createBill(BillDTO billDTO) ;
    int countBills();
}
