package com.library_management_system.backend.service.IMPL;

import com.library_management_system.backend.dto.AdminDTO;
import com.library_management_system.backend.dto.AuthenticationRequestDTO;
import com.library_management_system.backend.entity.Admin;
import com.library_management_system.backend.exception.customException.CustomAdminException;
import com.library_management_system.backend.repo.AdminRepo;
import com.library_management_system.backend.service.AdminService;
import com.library_management_system.backend.util.JwtUtil;
import com.library_management_system.backend.util.response.LoginResponse;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@Transactional
@RequiredArgsConstructor

public class AdminServiceImpl implements AdminService {

    private final AdminRepo adminRepo;
    private final ModelMapper modelMapper;
    private final AuthenticationManager authenticationManager;
    private final UserDetailsService userDetailsService;
    private final JwtUtil jwtUtil;


    @Override
    public LoginResponse logAdmin(AuthenticationRequestDTO dto) {
        try {
            Admin adminByUsername = adminRepo.getAdminByUsername(dto.getUserName());
            LoginResponse response = new LoginResponse();
            if (Objects.equals(adminByUsername, null)) {
                throw new BadCredentialsException("invalid details");
            }
            Authentication authenticate = authenticationManager.authenticate(new
                    UsernamePasswordAuthenticationToken(adminByUsername.getUserName(),
                    dto.getUserPassword()));
            UserDetails userDetails = userDetailsService.loadUserByUsername(adminByUsername.getUserName());
            String jwt = jwtUtil.generateToken(userDetails);
            String refreshToken = jwtUtil.generateRefreshToken(userDetails);
            response.setUserName(adminByUsername.getUserName());
            response.setCode(200);
            response.setJwt(jwt);
            response.setUserId(adminByUsername.getId());
            response.setMessage("login success");
            response.setRefreshToken(refreshToken);
            return response;


        } catch (Exception e) {
            throw new BadCredentialsException("invalid details");
        }
    }

    @Override
    public LoginResponse saveAdmin(AdminDTO admin) {
        Admin adminByUsername = adminRepo.getAdminByUsername(admin.getUserName());
        LoginResponse response = new LoginResponse();
        if (Objects.isNull(adminByUsername)) {
            Admin adminEntity = modelMapper.map(admin, Admin.class);
            adminEntity.setPassword(BCrypt.hashpw(admin.getPassword(), BCrypt.gensalt(10)));
            adminEntity.setRole("Admin");
            adminEntity.setStatus("Active");
            Admin savedAdmin = adminRepo.save(adminEntity);
            Authentication authenticate = authenticationManager.authenticate(new
                    UsernamePasswordAuthenticationToken(savedAdmin.getUserName(),
                    admin.getPassword()));
            UserDetails userDetails = userDetailsService.loadUserByUsername(savedAdmin.getUserName());
            String jwt = jwtUtil.generateToken(userDetails);
            String refreshToken = jwtUtil.generateRefreshToken(userDetails);
            response.setUserName(savedAdmin.getUserName());
            response.setCode(200);
            response.setJwt(jwt);
            response.setUserId(savedAdmin.getId());
            response.setMessage("login success");
            response.setRefreshToken(refreshToken);
            return response;
        }
        throw new CustomAdminException("Admin already exists with this username: " + admin.getUserName());
    }

    @Override
    public Admin getAdminByUserName(String UserName) {
    Admin admin = adminRepo.getAdminByUsername(UserName);
        if (!Objects.isNull(admin)) {
            return admin;
        }
        throw new CustomAdminException("Admin not exists with this username: " + admin.getUserName());

    }

    @Override
    public Admin updateAdmin(AdminDTO adminDTO) {
        Admin adminById = adminRepo.getAdminById(adminDTO.getId());
        System.out.println("Admin By Id: " + adminById);
        if (!Objects.isNull(adminById)) {
            Admin map = modelMapper.map(adminDTO, Admin.class);
            map.setStatus("Active");
            map.setRole("Admin");
            map.setPassword(adminById.getPassword());
            return adminRepo.save(map);
        }
        throw new CustomAdminException("Admin not exists with this userId: " + adminDTO.getId());

    }

    @Override
    public List<AdminDTO> getAdmins() {
        return modelMapper.map(adminRepo.getAll(),new TypeToken<ArrayList<AdminDTO>>(){}.getType());
    }

    @Override
    public Admin deleteAdmin(long adminId) {
    Admin admin = adminRepo.getAdminById(adminId);
    if (!Objects.isNull(admin)) {
        admin.setStatus("Inactive");
        return adminRepo.save(admin);
    }
        throw new CustomAdminException("Admin not exists with this userId: " + adminId);
    }
}
