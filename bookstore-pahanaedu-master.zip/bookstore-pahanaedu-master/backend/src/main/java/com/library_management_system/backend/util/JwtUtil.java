package com.library_management_system.backend.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.function.Function;

@Component
public class JwtUtil {
    @Value("${SECRET_KEY}")
    private String SECRET_KEY ;

    public String extractUser (String token) throws ExpiredJwtException {
        return extractClaim(token, Claims::getSubject);
    }

    public String extractType (String token) throws ExpiredJwtException {
        return (String) extractAllClaims(token).get("type");
    }

    public Date extractExpiration(String token){
        return extractClaim(token, Claims::getExpiration);
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    public Claims extractAllClaims(String token) throws ExpiredJwtException{
        return Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
    }

    private boolean isTokenExpired(String token) throws ExpiredJwtException{
        return extractExpiration(token).before(new Date());
    }

    public String generateToken(UserDetails userDetails ){
        Map<String, Object> claims = new HashMap<>();
        //claims.put("type", userType);
        return creteToken(claims,userDetails.getUsername());
    }

    public String generateTokenRoles(UserDetails userDetails, List<String> userType ){
        Map<String, Object> claims = new HashMap<>();
        claims.put("type", userType);
        return creteToken(claims,userDetails.getUsername());
    }

    private String creteToken(Map<String, Object> claims, String subject){
        return Jwts.builder().setClaims(claims).setSubject(subject).setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis()+1000*60*60*24))
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY).compact();
    }

    public String generateRefreshToken(UserDetails userDetails) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("type", "refresh");
        return createToken(claims, userDetails.getUsername(), 30 * 24 * 60 * 60 * 1000); // 30 days for refresh token
    }

    private String createToken(Map<String, Object> claims, String subject, long expirationTime) {
        return Jwts.builder()
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + expirationTime))
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY)
                .compact();
    }




    /*    Jwts.builder() kiyna method ekta  setSubject kiyna method ekta userName ekda token ek hdunu time ekai
     *     hadunu time eke idn kochchr kalyk token ek tyenna onmda kiyna ekai => .setExpiration(new Date(System.currentTimeMillis()+1000*60*60*24))
     *     SignatureAlgorithm ekai SECRET_KEY ekai denwa ethkot token ekk create krala denwa
     * */



    public Boolean validateToken(String token, UserDetails userDetails){
        final String userName = extractUser(token); //valid token ekkda blnwa mage token ek mn mada ewal tynne kiyla blwna
        return (userName.equals(userDetails.getUsername())) && !isTokenExpired(token);
    }

    public static String encode(String data) {
        return Base64.getEncoder().encodeToString(data.getBytes());
    }

    public static String decode(String encodedData) {
        return new String(Base64.getDecoder().decode(encodedData));
    }
}
