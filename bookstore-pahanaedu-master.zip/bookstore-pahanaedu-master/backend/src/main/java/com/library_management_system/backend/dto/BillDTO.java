package com.library_management_system.backend.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BillDTO {

    private Long id;
    private Date billDate;
    private Long customerId;
    private double totalAmount;
    private String status;

    private List<BookDTO> bookDTOS;
}
