package com.library_management_system.backend.exception.customException;

public class CustomAdminException extends RuntimeException{
    public CustomAdminException(String msg) {
        super(msg);
    }


}
