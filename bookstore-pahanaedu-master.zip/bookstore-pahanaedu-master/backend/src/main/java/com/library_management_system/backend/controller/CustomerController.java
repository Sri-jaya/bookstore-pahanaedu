package com.library_management_system.backend.controller;

import com.library_management_system.backend.dto.AuthenticationRequestDTO;
import com.library_management_system.backend.dto.CustomerDTO;
import com.library_management_system.backend.entity.Customer;
import com.library_management_system.backend.service.CustomerService;
import com.library_management_system.backend.util.response.LoginResponse;
import com.library_management_system.backend.util.response.StandardResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/customer")
@CrossOrigin(origins = "*",allowedHeaders = "*")
@RequiredArgsConstructor
public class CustomerController {

    private final CustomerService customerService;

    @PostMapping(path = "/save")
    public ResponseEntity<StandardResponse> saveCustomer(@RequestBody CustomerDTO dto){
        Customer save = customerService.save(dto);
        return new ResponseEntity<>(
                new StandardResponse(200, "success", save),
                HttpStatus.OK
        );
    }

    @GetMapping(params = {"id"})
    public ResponseEntity<StandardResponse> getCustomerById(@RequestParam Long id){
        Customer customer = customerService.getCustomerById(id);
        return new ResponseEntity<>(
                new StandardResponse(200, "success", customer),
                HttpStatus.OK
        );
    }

    @PutMapping(path = "/update")
    public ResponseEntity<StandardResponse> updateCustomer(@RequestBody CustomerDTO customerDTO){
        Customer updatedCustomer = customerService.updateCustomer(customerDTO);
        return new ResponseEntity<>(
                new StandardResponse(200, "success", updatedCustomer),
                HttpStatus.OK
        );
    }

    @DeleteMapping(path = "/delete", params = {"id"})
    public ResponseEntity<StandardResponse> deleteCustomer(@RequestParam Long id){
        Customer deletedCustomer = customerService.deleteCustomer(id);
        return new ResponseEntity<>(
                new StandardResponse(200, "success", deletedCustomer),
                HttpStatus.OK
        );
    }

    @GetMapping(path = "/getAll")
    public ResponseEntity<StandardResponse> getAllCustomers() {
        return new ResponseEntity<>(
                new StandardResponse(200, "success", customerService.getAllCustomers()),
                HttpStatus.OK
        );
    }

    @GetMapping(path = "/count")
    public ResponseEntity<StandardResponse> getActiveCustomersCount() {
        int activeCount = customerService.getActiveCustomersCount();
        return new ResponseEntity<>(
                new StandardResponse(200, "success", activeCount),
                HttpStatus.OK
        );
    }
}
