package com.library_management_system.backend.exception.customException;

public class CustomBillException extends RuntimeException{
    public CustomBillException(String msg) {
        super(msg);
    }
}
