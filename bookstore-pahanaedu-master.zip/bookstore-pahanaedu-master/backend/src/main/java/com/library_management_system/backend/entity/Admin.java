package com.library_management_system.backend.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;



@Entity
@Table(name = "admin")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Admin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "admin_id")
    private Long id;

    @Column(name = "user_name")
    @NonNull
    private String userName;

    @Column(name = "password")
    @NonNull
    private String password;

    @Column(name = "status")
    @NonNull
    private String status;

    @Column(name = "role")
    @NonNull
    private String role;
}
