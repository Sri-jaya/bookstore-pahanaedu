package com.library_management_system.backend.filter;

import com.library_management_system.backend.service.UserDetailService;
import com.library_management_system.backend.util.JwtUtil;
import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;


import java.util.Map;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    JwtUtil jwtUtil;

    @Autowired
    UserDetailService userDetailService;

    @SneakyThrows
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
        final String authorizationHeader = request.getHeader("Authorization");//rq header eke Authorization tyda kila allgannwa
        String userName = null;
        String jwt = null;
        Map<String, Long> map = null;
        try {
            if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")){  //authorizationHeader meka null ntnm saha header eka patan ganiddi Bearer tyda kiyla blanawa
                jwt = authorizationHeader.substring(7); //authorizationHeader eke character 7k tyda blanwa  'Bearer' ha space eka tynam mul character 7 adu krla anit tika token ekt gnna kiynwa
                try {
                    userName = jwtUtil.extractUser(jwt); //user name ek extract krala denwa
                    Claims claims = jwtUtil.extractAllClaims(jwt);
                    request.setAttribute("user",userName);
                    request.setAttribute("type",claims.get("type"));
                } catch (Exception e) {
                    request.setAttribute("code", 401);
                    request.setAttribute("message", "Expired JWT token");
                    request.setAttribute("error",e.getMessage());
                    SecurityContextHolder.clearContext();
                }
            } else {
                request.setAttribute("code", 404);
                request.setAttribute("message", "Token is Missing");
                request.setAttribute("error", "Token is null");
                SecurityContextHolder.clearContext();
            }

            if (userName != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                UserDetails userDetails = this.userDetailService.loadUserByUsername(userName);
                if (jwtUtil.validateToken(jwt, userDetails)){ //jwt token ek valid token ekkda kiyl check krnwa
                    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
                            userDetails, null, userDetails.getAuthorities());
                    usernamePasswordAuthenticationToken.setDetails(map);
                    SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
                } else {
                    request.setAttribute("code", 401);
                    request.setAttribute("message", "Token Exception");
                    request.setAttribute("error", "Token is not valid");
                    SecurityContextHolder.clearContext();
                    throw new AuthenticationCredentialsNotFoundException("Token is not valid");
                }
            }
        } catch (Exception e) {
            request.setAttribute("code", 400);
            request.setAttribute("message", "Filter Exception");
            request.setAttribute("error",e.getMessage());
            SecurityContextHolder.clearContext();
        }

        filterChain.doFilter(request, response);
    }
}
