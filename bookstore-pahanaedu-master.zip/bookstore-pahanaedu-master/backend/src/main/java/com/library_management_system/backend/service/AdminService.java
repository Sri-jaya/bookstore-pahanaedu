package com.library_management_system.backend.service;

import com.library_management_system.backend.dto.AdminDTO;
import com.library_management_system.backend.dto.AuthenticationRequestDTO;
import com.library_management_system.backend.entity.Admin;
import com.library_management_system.backend.util.response.LoginResponse;

import java.util.List;

public interface AdminService {
    LoginResponse logAdmin(AuthenticationRequestDTO dto);
    LoginResponse  saveAdmin(AdminDTO admin);
    Admin getAdminByUserName(String UserName);
    Admin updateAdmin(AdminDTO adminDTO);
    List<AdminDTO> getAdmins();
    Admin deleteAdmin(long adminId);

}
