package com.library_management_system.backend.entity;

import com.sun.istack.NotNull;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.util.Date;

@Entity
@Table(name = "customer")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "customer_id")
    private Long id;

    @Column(name = "customer_name")
    @NotNull
    private String customerName;

    @Column(name = "address")
    @NotNull
    private String address;

    @Column(name = "phone_number")
    @NotNull
    private String phoneNumber;

    @Temporal(TemporalType.DATE)
    @Column(name = "registration_date")
    @NotNull
    private Date registrationDate;

    @Column(name = "unit_consumed")
    @NotNull
    private int unitConsumed;

    @Column(name = "status")
    @NotNull
    private String status;

}
