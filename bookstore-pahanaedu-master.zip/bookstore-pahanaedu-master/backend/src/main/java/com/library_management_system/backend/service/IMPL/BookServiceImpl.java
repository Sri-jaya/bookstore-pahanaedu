package com.library_management_system.backend.service.IMPL;

import com.library_management_system.backend.dto.BookDTO;
import com.library_management_system.backend.dto.CustomerDTO;
import com.library_management_system.backend.entity.Books;
import com.library_management_system.backend.exception.customException.CustomBooksException;
import com.library_management_system.backend.repo.BooksRepo;
import com.library_management_system.backend.repo.CustomerRepo;
import com.library_management_system.backend.service.BookService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.stereotype.Service;

import java.awt.print.Book;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@Transactional
@RequiredArgsConstructor
public class BookServiceImpl implements BookService {

    private final BooksRepo booksRepo;
    private final ModelMapper modelMapper;


    @Override
    public Books saveBook(BookDTO book) {
        Books bookById = booksRepo.getBookById(book.getId());
        if(Objects.isNull(bookById)){
            Books map = modelMapper.map(book, Books.class);
            map.setStatus("Active");
            return booksRepo.save(map);
        }
        throw new CustomBooksException("Book not saved, book with this id already exists");
    }

    @Override
    public Books getBookById(Long bookId) {
        Books bookById = booksRepo.getBookById(bookId);
        if(!Objects.isNull(bookById)){
            return bookById;
        }
        throw new CustomBooksException("Book id not found, please check the book id");

    }

    @Override
    public Books updateBook(BookDTO book) {
        Books bookById = booksRepo.getBookById(book.getId());
        if(!Objects.isNull(bookById)){
            Books map = modelMapper.map(book, Books.class);
            map.setStatus("Active");
            return booksRepo.save(map);
        }
        throw new CustomBooksException("Book id not found, please check the book id");
    }

    @Override
    public Books deleteBook(Long bookId) {
        Books bookById = booksRepo.getBookById(bookId);
        if(!Objects.isNull(bookById)){
            bookById.setStatus("Inactive");
            return booksRepo.save(bookById);
        }
        throw new CustomBooksException("Book id not found, please check the book id");

    }

    @Override
    public Books getBookByName(String bookName) {
        Books bookByName = booksRepo.getBookByName(bookName);
        if(!Objects.isNull(bookByName)){
            return bookByName;
        }
        throw new CustomBooksException("Book name not found, please check the book name");

    }

    @Override
    public List<Books> getBookByCategory(String category) {
        return  booksRepo.getBookByCategory(category);
    }

    @Override
    public List<String> getAllBookCategories() {
        return booksRepo.getAllBookCategories();
    }

    @Override
    public List<BookDTO> getAllBooks() {
        return modelMapper.map(booksRepo.getAllBooks(),new TypeToken<ArrayList<BookDTO>>(){}.getType());

    }

    @Override
    public int getActiveBooksCount() {
        return booksRepo.getActiveBooksCount();
    }
}
