package com.library_management_system.backend.exception;

import com.library_management_system.backend.exception.customException.CustomAdminException;
import com.library_management_system.backend.exception.customException.CustomBillException;
import com.library_management_system.backend.exception.customException.CustomBooksException;
import com.library_management_system.backend.exception.customException.CustomCustomerException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(CustomAdminException.class)
    public ResponseEntity<Map<String, Object>> handleBadCredentials(CustomAdminException ex){
        Map<String, Object> errorBody = new HashMap<>();
        errorBody.put("code", 400);
        errorBody.put("message", ex.getMessage());
        return new ResponseEntity<>(errorBody, HttpStatus.BAD_REQUEST);
    }


    @ExceptionHandler(CustomCustomerException.class)
    public ResponseEntity<Map<String, Object>> handleCustomerException(CustomCustomerException ex) {
        Map<String, Object> errorBody = new HashMap<>();
        errorBody.put("code", 400);
        errorBody.put("message", ex.getMessage());
        return new ResponseEntity<>(errorBody, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(CustomBooksException.class)
    public ResponseEntity<Map<String, Object>> handleBooksException(CustomBooksException ex) {
        Map<String, Object> errorBody = new HashMap<>();
        errorBody.put("code", 400);
        errorBody.put("message", ex.getMessage());
        return new ResponseEntity<>(errorBody, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(CustomBillException.class)
    public ResponseEntity<Map<String, Object>> handleBillException(CustomBillException ex) {
        Map<String, Object> errorBody = new HashMap<>();
        errorBody.put("code", 400);
        errorBody.put("message", ex.getMessage());
        return new ResponseEntity<>(errorBody, HttpStatus.BAD_REQUEST);
    }

}
