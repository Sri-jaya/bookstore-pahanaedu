package com.library_management_system.backend.service;

import com.library_management_system.backend.dto.BookDTO;
import com.library_management_system.backend.entity.Books;

import java.awt.print.Book;
import java.util.List;

public interface BookService {

    Books saveBook(BookDTO book);
    Books getBookById(Long bookId);
    Books updateBook(BookDTO book);
    Books deleteBook(Long bookId);
    Books getBookByName(String bookName);
    List<Books> getBookByCategory(String category);
    List<String> getAllBookCategories();
    List<BookDTO> getAllBooks();
    int getActiveBooksCount();
}
