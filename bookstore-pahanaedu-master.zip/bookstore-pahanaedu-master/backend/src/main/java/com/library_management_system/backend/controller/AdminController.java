package com.library_management_system.backend.controller;

import com.library_management_system.backend.dto.AdminDTO;
import com.library_management_system.backend.dto.AuthenticationRequestDTO;
import com.library_management_system.backend.entity.Admin;
import com.library_management_system.backend.service.AdminService;
import com.library_management_system.backend.util.response.LoginResponse;
import com.library_management_system.backend.util.response.StandardResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin")
@CrossOrigin(origins = "*",allowedHeaders = "*")
@RequiredArgsConstructor
public class AdminController {

    private final AdminService adminService;

    @PostMapping(path = "/login")
    public ResponseEntity<LoginResponse> adminLogin(@RequestBody AuthenticationRequestDTO dto){
        LoginResponse loginResponse = adminService.logAdmin(dto);
        return new ResponseEntity<LoginResponse>(
                loginResponse,
                HttpStatus.OK
        );
    }

    @PostMapping(path = "/signUp")
    public ResponseEntity<LoginResponse> adminSignUp(@RequestBody AdminDTO  dto) {
        LoginResponse loginResponse = adminService.saveAdmin(dto);
        return new ResponseEntity<LoginResponse>(
                loginResponse,
                HttpStatus.OK
        );
    }

    @GetMapping(params = {"userName"})
    public ResponseEntity<StandardResponse> getAdminById(@RequestParam String userName) {
        Admin admin = adminService.getAdminByUserName(userName);
        return new ResponseEntity<>(
                new StandardResponse(200, "success", admin),
                HttpStatus.OK
        );
    }

    @PutMapping(path = "/update")
    public ResponseEntity<StandardResponse> updateAdmin(@RequestBody AdminDTO adminDTO) {
        Admin updatedAdmin = adminService.updateAdmin(adminDTO);
        return new ResponseEntity<>(
                new StandardResponse(200, "success", updatedAdmin),
                HttpStatus.OK
        );
    }

    @GetMapping(path = "/getAll")
    public ResponseEntity<StandardResponse> getAllAdmins() {
        return new ResponseEntity<>(
                new StandardResponse(200, "success", adminService.getAdmins()),
                HttpStatus.OK
        );
    }

    @DeleteMapping(params = {"adminId"})
    public ResponseEntity<StandardResponse> deleteAdmin(@RequestParam long adminId) {
        Admin deletedAdmin = adminService.deleteAdmin(adminId);
        return new ResponseEntity<>(
                new StandardResponse(200, "success", deletedAdmin),
                HttpStatus.OK
        );
    }
}
