package com.library_management_system.backend.service.IMPL;

import com.library_management_system.backend.dto.BillHasBooksDTO;
import com.library_management_system.backend.dto.BookDTO;
import com.library_management_system.backend.entity.BillHasBooks;
import com.library_management_system.backend.entity.Books;
import com.library_management_system.backend.exception.customException.CustomBooksException;
import com.library_management_system.backend.repo.BillHasBooksRepo;
import com.library_management_system.backend.repo.BooksRepo;
import com.library_management_system.backend.service.BillHasBooksService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@Transactional
@RequiredArgsConstructor
public class BillHasBooksServiceImpl implements BillHasBooksService {

    private final BillHasBooksRepo billHasBooksRepo;
    private final BooksRepo booksRepo;



    @Override
    public int addBookToBill(Long billId, List<BookDTO> books) {
       int unitConsumed =0;
        for (BookDTO bookDTO : books) {
            // Save to bill_has_books
            BillHasBooks entry = new BillHasBooks();
            entry.setBillId(billId);
            entry.setBookId(bookDTO.getId());
            entry.setQuantity(bookDTO.getStockQty()); // qty purchased
            entry.setPricePerUnit(bookDTO.getPrice());
            billHasBooksRepo.save(entry);
            unitConsumed = unitConsumed+ bookDTO.getStockQty();

            Books book = booksRepo.getBookById(bookDTO.getId());
            if (book != null) {
                if (book.getStockQty() >= bookDTO.getStockQty()) {
                    int newStock = book.getStockQty() - bookDTO.getStockQty();
                    book.setStockQty(newStock);
                    booksRepo.save(book);

                } else {
                    throw new CustomBooksException("Not enough stock for book: " + book.getName());
                }
            } else {
                throw new CustomBooksException("Book not found: ID " + bookDTO.getId());
            }
        }
        return unitConsumed;
    }


}
