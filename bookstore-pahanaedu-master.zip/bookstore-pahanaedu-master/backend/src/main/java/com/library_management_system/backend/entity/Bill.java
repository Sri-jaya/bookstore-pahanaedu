package com.library_management_system.backend.entity;

import com.sun.istack.NotNull;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.util.Date;

@Entity
@Table(name = "bill")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Bill {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bill_id")
    private Long id;

    @Temporal(TemporalType.DATE)
    @Column(name = "bill_date")
    @NotNull
    private Date billDate;

    @Column(name = "customer_id")
    @NotNull
    private Long customerId;

    @Column(name = "total_amount")
    @NotNull
    private double totalAmount;

    @Column(name = "status")
    @NotNull
    private String status;

}
