package com.library_management_system.backend.service.IMPL;

import com.library_management_system.backend.dto.BillDTO;
import com.library_management_system.backend.dto.BillHasBooksDTO;
import com.library_management_system.backend.dto.BookDTO;
import com.library_management_system.backend.entity.Bill;
import com.library_management_system.backend.entity.BillHasBooks;
import com.library_management_system.backend.entity.Books;
import com.library_management_system.backend.entity.Customer;
import com.library_management_system.backend.exception.customException.CustomBillException;
import com.library_management_system.backend.exception.customException.CustomCustomerException;
import com.library_management_system.backend.repo.BillHasBooksRepo;
import com.library_management_system.backend.repo.BillRepo;
import com.library_management_system.backend.repo.BooksRepo;
import com.library_management_system.backend.repo.CustomerRepo;
import com.library_management_system.backend.service.BillHasBooksService;
import com.library_management_system.backend.service.BillService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
@Transactional
@RequiredArgsConstructor
public class BillServiceImpl implements BillService {

    private final ModelMapper modelMapper;
    private final BillRepo billRepo;
    private final CustomerRepo customerRepo;
    private final BillHasBooksService billHasBooksService;

    @Override
    public Bill createBill(BillDTO billDTO) {
        Bill billById = billRepo.getBillById(billDTO.getId());

        if (Objects.isNull(billById)) {
            Bill bill = modelMapper.map(billDTO, Bill.class);
            bill.setStatus("Active");
            bill.setBillDate(new Date());
            Bill savedBill = billRepo.save(bill);

            // Call book saving and stock update logic
            int unitConsumed = billHasBooksService.addBookToBill(savedBill.getId(),
                    billDTO.getBookDTOS());
            changeCustomerUnitConsumed(unitConsumed, billDTO.getCustomerId());
            return savedBill;
        }
        throw new CustomBillException("Bill already exists with this id: " + billDTO.getId());
    }

    @Override
    public int countBills() {
        return billRepo.getActiveBillCount();

    }

    private void changeCustomerUnitConsumed(int unitConsumed,long customerId){
        Customer customerById = customerRepo.getCustomerById(customerId);
        if (customerById != null) {
            customerById.setUnitConsumed(unitConsumed+ customerById.getUnitConsumed());
            customerRepo.save(customerById);
        }
    }

}




