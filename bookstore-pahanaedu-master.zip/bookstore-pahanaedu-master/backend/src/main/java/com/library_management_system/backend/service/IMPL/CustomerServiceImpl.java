package com.library_management_system.backend.service.IMPL;

import com.library_management_system.backend.dto.AdminDTO;
import com.library_management_system.backend.dto.CustomerDTO;
import com.library_management_system.backend.entity.Customer;
import com.library_management_system.backend.exception.customException.CustomAdminException;
import com.library_management_system.backend.exception.customException.CustomCustomerException;
import com.library_management_system.backend.repo.CustomerRepo;
import com.library_management_system.backend.service.CustomerService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
@Transactional
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepo customerRepo;
    private final ModelMapper modelMapper;


    @Override
    public Customer save(CustomerDTO customer) {

        Customer customerById = customerRepo.getCustomerById(customer.getId());
        if(Objects.isNull(customerById)){
            Customer map = modelMapper.map(customer, Customer.class);
            map.setStatus("Active");
            map.setUnitConsumed(0);
            map.setRegistrationDate(new Date());
            return customerRepo.save(map);
        }

        throw new CustomCustomerException("Customer already exists with this id: " + customer.getId());
    }

    @Override
    public Customer getCustomerById(Long id) {

    Customer customerById = customerRepo.getCustomerById(id);
        if(!Objects.isNull(customerById)){
            return customerById;
        }
        throw new CustomCustomerException("Customer not exists with this id: " + id);

    }

    @Override
    public Customer updateCustomer(CustomerDTO customerDTO) {
        Customer customerById = customerRepo.getCustomerById(customerDTO.getId());
        if(!Objects.isNull(customerById)){
            Customer map = modelMapper.map(customerDTO, Customer.class);
            map.setStatus("Active");
            map.setUnitConsumed(customerById.getUnitConsumed());
            map.setRegistrationDate(customerById.getRegistrationDate());
            return customerRepo.save(map);
        }
        throw new CustomCustomerException("Customer not exists with this id: " + customerDTO.getId());

    }

    @Override
    public Customer deleteCustomer(Long id) {
        Customer customerById = customerRepo.getCustomerById(id);
        if(!Objects.isNull(customerById)){
            customerById.setStatus("Inactive");
            return customerRepo.save(customerById);
        }
        throw new CustomCustomerException("Customer not exists with this id: " + id);
    }

    @Override
    public List<CustomerDTO> getAllCustomers() {
        return modelMapper.map(customerRepo.getActiveCustomers(),new TypeToken<ArrayList<CustomerDTO>>(){}.getType());

    }

    @Override
    public int getActiveCustomersCount() {
        return customerRepo.getActiveCustomerCount();

    }


}
