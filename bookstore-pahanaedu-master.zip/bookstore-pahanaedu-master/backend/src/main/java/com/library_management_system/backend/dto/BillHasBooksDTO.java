package com.library_management_system.backend.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BillHasBooksDTO {

    private Long id;
    private long billId;
    private long bookId;
    private int quantity;
    private double pricePerUnit;
}
