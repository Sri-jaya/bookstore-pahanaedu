package com.library_management_system.backend.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Entity
@Table(name = "bill_has_books")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BillHasBooks {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bill_has_books_id")
    private Long id;

    @Column(name = "bill_id")
    private long billId;

    @Column(name = "book_id")
    private long bookId;

    @Column(name = "quantity")
    private int quantity;

    @Column(name = "price_per_unit")
    private double pricePerUnit;



}
