package com.library_management_system.backend.repo;

import com.library_management_system.backend.entity.Books;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BooksRepo extends JpaRepository<Books, Long> {

    @Query(value = "select * from books where book_id =:bookId and status='Active'",nativeQuery = true)
    Books getBookById(@Param("bookId") Long bookId);

    @Query(value = "select * from books where status='Active'", nativeQuery = true)
    List<Books> getAllBooks();

    @Query( value = "select * from books where name =:bookName and status='Active'",nativeQuery = true)
    Books getBookByName(@Param("bookName")String bookName);

    @Query(value = "select ctegory from books",nativeQuery = true)
    List<String> getAllBookCategories();

    @Query(value = "select * from books where ctegory =:category and status='Active'",nativeQuery = true)
    List<Books> getBookByCategory(@Param("category") String category);

    @Query(value = "SELECT COUNT(*) AS item_count FROM books where status ='Active'",nativeQuery = true)
    int getActiveBooksCount();

}
