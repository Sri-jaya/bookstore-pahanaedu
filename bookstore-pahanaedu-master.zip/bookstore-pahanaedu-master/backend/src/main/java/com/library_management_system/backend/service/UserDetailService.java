package com.library_management_system.backend.service;

import com.library_management_system.backend.entity.Admin;
import com.library_management_system.backend.repo.AdminRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class UserDetailService implements UserDetailsService {

    @Autowired
    AdminRepo userRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Admin adminByUsername = userRepo.getAdminByUsername(username);
        String password = "";
        List<SimpleGrantedAuthority> authorities = new ArrayList<>();
        //List<String> userRoleByUserId = tblAuthUserRolesRepo.getUserRoleByUserId(tblAuthUser.getUserId());


        if (!Objects.equals(adminByUsername,null)){
            //authorities.add(new SimpleGrantedAuthority(userRoleByUserId.toString()));
            password = adminByUsername.getPassword();
        }

        return new org.springframework.security.core.userdetails.User(username, password, authorities);
    }
}
