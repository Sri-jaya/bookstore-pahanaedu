package com.library_management_system.backend.controller;

import com.library_management_system.backend.dto.AuthenticationRequestDTO;
import com.library_management_system.backend.dto.BillDTO;
import com.library_management_system.backend.entity.Bill;
import com.library_management_system.backend.service.BillService;
import com.library_management_system.backend.util.response.LoginResponse;
import com.library_management_system.backend.util.response.StandardResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/bill")
@CrossOrigin(origins = "*",allowedHeaders = "*")
@RequiredArgsConstructor
public class BillController {

    private final BillService billService;

    @PostMapping(path = "/save")
    public ResponseEntity<StandardResponse> saveBill(@RequestBody BillDTO dto){
        Bill bill = billService.createBill(dto);
        return new ResponseEntity<>(
                new StandardResponse(200, "success", bill),
                HttpStatus.OK
        );
    }

    @GetMapping(path = "/count")
    public ResponseEntity<StandardResponse> countBills() {
        int count = billService.countBills();
        return new ResponseEntity<>(
                new StandardResponse(200, "success", count),
                HttpStatus.OK
        );
    }

}
