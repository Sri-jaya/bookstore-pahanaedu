package com.library_management_system.backend.util.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class LoginResponse {
    private int code;
    private String userName;
    private String message;
    private String jwt;
    private String refreshToken;
    private long userId;
}
