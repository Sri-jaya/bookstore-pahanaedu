package com.library_management_system.backend.service;

import com.library_management_system.backend.dto.BillHasBooksDTO;
import com.library_management_system.backend.dto.BookDTO;

import java.util.List;

public interface BillHasBooksService {

    int addBookToBill(Long billId, List<BookDTO> books);
}
