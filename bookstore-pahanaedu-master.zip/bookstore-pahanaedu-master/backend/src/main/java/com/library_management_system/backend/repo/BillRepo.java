package com.library_management_system.backend.repo;

import com.library_management_system.backend.entity.Bill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface BillRepo extends JpaRepository<Bill, Long> {

    @Query(value="select * from bill  where bill_id =:billId and status='Active'",nativeQuery = true)
    Bill getBillById(@Param("billId") Long billId);

    @Query(value = "SELECT COUNT(*) AS bill_count FROM bill where status ='Active'",nativeQuery = true)
    int getActiveBillCount();


}
