package com.library_management_system.backend.repo;

import com.library_management_system.backend.entity.Admin;
import com.library_management_system.backend.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerRepo extends JpaRepository<Customer, Long> {

    @Query(value = "select * from customer where customer_id=:customerId and status='Active'", nativeQuery = true)
    Customer getCustomerById(@Param("customerId") Long customerId);

    @Query(value ="select * from customer where status='Active'",nativeQuery = true)
    List<Customer> getActiveCustomers();

    @Query(value = "SELECT COUNT(*) AS customer_count FROM customer where status ='Active'", nativeQuery = true)
    int getActiveCustomerCount();



}
