package com.library_management_system.backend.repo;

import com.library_management_system.backend.entity.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AdminRepo extends JpaRepository<Admin, Long> {

    @Query(value = "select *  from  admin where  user_name =:userName and status ='Active'",nativeQuery = true)
    Admin getAdminByUsername(@Param("userName") String userName);

    @Query(value = "select * from admin  where admin_id =:adminId and status ='Active'", nativeQuery = true)
    Admin getAdminById(@Param("adminId") Long adminId);

    @Query(value = "select  * from admin where status='Active'",nativeQuery = true)
    List<Admin> getAll();


}
