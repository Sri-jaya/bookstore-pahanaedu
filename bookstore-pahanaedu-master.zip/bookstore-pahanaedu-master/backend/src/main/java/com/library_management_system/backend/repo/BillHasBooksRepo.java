package com.library_management_system.backend.repo;

import com.library_management_system.backend.entity.Bill;
import com.library_management_system.backend.entity.BillHasBooks;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BillHasBooksRepo extends JpaRepository<BillHasBooks, Long> {

    @Query(value = "select * from bill_has_books where bill_id =:billId",nativeQuery = true)
    List<BillHasBooks> findByBillId(@Param("billId") Long billId);
}
