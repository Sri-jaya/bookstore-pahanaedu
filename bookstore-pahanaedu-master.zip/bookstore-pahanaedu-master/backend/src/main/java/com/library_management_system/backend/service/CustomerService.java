package com.library_management_system.backend.service;

import com.library_management_system.backend.dto.CustomerDTO;
import com.library_management_system.backend.entity.Customer;

import java.util.List;

public interface CustomerService {

    Customer save(CustomerDTO customer);
    Customer getCustomerById(Long id);
    Customer updateCustomer(CustomerDTO customerDTO);
    Customer deleteCustomer(Long id);
    List<CustomerDTO> getAllCustomers();
    int getActiveCustomersCount();

}
