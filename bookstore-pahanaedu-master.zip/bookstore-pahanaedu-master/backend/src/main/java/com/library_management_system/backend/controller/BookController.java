package com.library_management_system.backend.controller;

import com.library_management_system.backend.dto.BookDTO;
import com.library_management_system.backend.dto.CustomerDTO;
import com.library_management_system.backend.entity.Books;
import com.library_management_system.backend.entity.Customer;
import com.library_management_system.backend.service.BookService;
import com.library_management_system.backend.util.response.StandardResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/books")
@CrossOrigin(origins = "*",allowedHeaders = "*")
@RequiredArgsConstructor
public class BookController {

    private final BookService bookService;

    @PostMapping(path = "/save")
    public ResponseEntity<StandardResponse> saveBook(@RequestBody BookDTO dto){
        Books books = bookService.saveBook(dto);
        return new ResponseEntity<>(
                new StandardResponse(200, "success", books),
                HttpStatus.OK
        );
    }

    @GetMapping(params = {"id"})
    public ResponseEntity<StandardResponse> getBookById(@RequestParam("id") Long id){
        Books bookById = bookService.getBookById(id);
        return new ResponseEntity<>(
                new StandardResponse(200, "success", bookById),
                HttpStatus.OK
        );
    }

    @PutMapping(path = "/update")
    public ResponseEntity<StandardResponse> updateBook(@RequestBody BookDTO dto){
        Books updatedBook = bookService.updateBook(dto);
        return new ResponseEntity<>(
                new StandardResponse(200, "success", updatedBook),
                HttpStatus.OK
        );
    }
    @GetMapping(params = {"name"})
    public ResponseEntity<StandardResponse> getBookByName(@RequestParam("name") String name){
        Books bookByName = bookService.getBookByName(name);
        return new ResponseEntity<>(
                new StandardResponse(200, "success", bookByName),
                HttpStatus.OK
        );
    }
    
    @GetMapping(params = {"category"})
    public ResponseEntity<StandardResponse> getBookByCategory(@RequestParam("category") String category){
        List<Books> bookByCategory = bookService.getBookByCategory(category);
        return new ResponseEntity<>(
                new StandardResponse(200, "success", bookByCategory),
                HttpStatus.OK
        );
    }
    
    @GetMapping(path = "/getAllBooks")
    public ResponseEntity<StandardResponse> getAllBooks(){
        List<BookDTO> allBooks = bookService.getAllBooks();
        return new ResponseEntity<>(
                new StandardResponse(200, "success", allBooks),
                HttpStatus.OK
        );
    }

    @GetMapping(path="/getAllActiveBooksByCategory")
    public ResponseEntity<StandardResponse> getAllActiveBooksByCategory(){
        List<String> allBookCategories = bookService.getAllBookCategories();
        return new ResponseEntity<>(
                new StandardResponse(200, "success", allBookCategories),
                HttpStatus.OK
        );
    }

    @DeleteMapping(params = {"id"})
    public ResponseEntity<StandardResponse> deleteBook(@RequestParam("id") Long id){
        Books deletedBook = bookService.deleteBook(id);
        return new ResponseEntity<>(
                new StandardResponse(200, "success", deletedBook),
                HttpStatus.OK
        );
    }

    @GetMapping(path = "/count")
    public ResponseEntity<StandardResponse> countActiveBooks() {
        int count = bookService.getActiveBooksCount();
        return new ResponseEntity<>(
                new StandardResponse(200, "success", count),
                HttpStatus.OK
        );
    }
}
