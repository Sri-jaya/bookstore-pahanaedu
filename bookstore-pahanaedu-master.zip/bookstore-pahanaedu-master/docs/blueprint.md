# **App Name**: Bookstore Billing Ace

## Core Features:

- Authentication: Login and registration with JWT based authentication.
- Customer Accounts Dashboard: Dashboard listing customer accounts with search and filtering.
- Add/Edit Customer Accounts: Add and edit customer accounts (number, name, address, phone, units).
- Manage Item Information: List, add, edit, and delete item information pages.
- Account Details: Customer account details page with billing history. Can be printed via browser functionality.
- Billing Calculation: Calculates bill based on units consumed using formula.
- Help Page: Help page with instructions using generative AI to help user with questions.

## Style Guidelines:

- Primary color: Soft blue (#A0CFEC) to convey trust and reliability.
- Background color: Light gray (#F5F5F5), providing a clean and modern look.
- Accent color: Muted green (#8FBC8F) for key actions and highlights.
- Body font: 'Inter', sans-serif, suitable for the body
- Headline font: 'Space Grotesk', sans-serif, to provide a clear and futuristic look. Paired with Inter for body text
- Simple, outline-style icons from a library like FontAwesome or Remix Icon, colored in the primary blue.
- Clean, grid-based layout using Tailwind CSS. Use whitespace to improve readability.
- Subtle transitions for page changes and interactive elements.