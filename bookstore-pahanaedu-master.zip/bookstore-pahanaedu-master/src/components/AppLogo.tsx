import { BookOpen } from 'lucide-react';

export function AppLogo() {
  return (
    <div className="flex items-center gap-2 my-2">
      <BookOpen className="h-6 w-6 text-primary" />
      <h1 className="text-xl font-bold font-headline text-foreground">
        Pahana Edu
      </h1>
    </div>
  );
}
