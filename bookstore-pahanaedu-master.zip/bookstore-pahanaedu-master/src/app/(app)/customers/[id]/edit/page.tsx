'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { CustomerForm } from '@/components/CustomerForm';
import type { Customer } from '@/types';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { authFetch } from '@/lib/authHandler';

export default function EditCustomerPage() {
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [loading, setLoading] = useState(false);
  const [pageLoading, setPageLoading] = useState(true);
  const router = useRouter();
  const params = useParams();
  const { toast } = useToast();
  const id = params.id as string;

  useEffect(() => {
    if (id) {
      const fetchCustomer = async () => {
        try {
          const res = await authFetch(
            `http://localhost:8080/api/v1/customer?id=${id}`
          );
          if (!res.ok) throw new Error('Failed to fetch customer');
          const data = await res.json();
          if (data.data) {
            setCustomer(data.data);
          } else {
            toast({
              title: 'Error',
              description: 'Customer not found.',
              variant: 'destructive',
            });
            router.push('/customers');
          }
        } catch (error) {
          toast({
            title: 'Error',
            description: 'Failed to fetch customer data.',
            variant: 'destructive',
          });
        } finally {
          setPageLoading(false);
        }
      };
      fetchCustomer();
    }
  }, [id, router, toast]);

  useEffect(() => {
    console.log(customer);
  }, [customer]);

  // Update customer
  const handleUpdateCustomer = async (formData: any) => {
    setLoading(true);
    console.log('formData:');
    console.log(formData);
    try {
      const updatedData = {
        ...formData,
        id: parseInt(id, 10),
        registrationDate:
          customer?.registrationDate || new Date().toISOString().slice(0, 10),
        status: customer?.status || 'Active',
      };
      console.log('updatedData:');
      console.log(updatedData);
      const res = await authFetch(
        'http://localhost:8080/api/v1/customer/update',
        {
          method: 'PUT',
          body: JSON.stringify(updatedData),
        }
      );
      if (!res.ok) throw new Error('Failed to update customer');
      toast({
        title: 'Success',
        description: 'Customer updated successfully.',
      });
      router.push('/customers');
      router.refresh();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update customer.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (pageLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Skeleton className="h-10 w-10" />
          <div className="space-y-2">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-5 w-80" />
          </div>
        </div>
        <Skeleton className="h-[500px] w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h2 className="text-3xl font-bold tracking-tight font-headline">
            Edit Customer
          </h2>
          <p className="text-muted-foreground">
            Editing account for {customer?.customerName}.
          </p>
        </div>
      </div>
      <CustomerForm
        initialData={customer}
        onSubmit={handleUpdateCustomer}
        loading={loading}
      />
    </div>
  );
}
