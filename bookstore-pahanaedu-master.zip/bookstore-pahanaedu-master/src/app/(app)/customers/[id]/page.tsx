'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import {
  getCustomerById,
  getBillsForCustomer,
  calculateAndSaveBill,
  getItemById,
} from '@/lib/api';
import type { Customer, Bill, Item } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowLeft, Printer, FileText } from 'lucide-react';

export default function CustomerDetailsPage() {
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [bills, setBills] = useState<Bill[]>([]);
  const [billingItem, setBillingItem] = useState<Item | null>(null);
  const [loading, setLoading] = useState(true);
  const [billingLoading, setBillingLoading] = useState(false);
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const id = params.id as string;

  const fetchData = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const customerData = await getCustomerById(id);
      if (!customerData) {
        toast({
          title: 'Error',
          description: 'Customer not found.',
          variant: 'destructive',
        });
        router.push('/customers');
        return;
      }
      const billsData = await getBillsForCustomer(id);
      const items = await getItemById('1'); // Assuming item with ID '1' is the billing unit

      setCustomer(customerData);
      setBills(billsData);
      if (items) setBillingItem(items);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch data.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [id]);

  const handleGenerateBill = async () => {
    setBillingLoading(true);
    try {
      await calculateAndSaveBill(id);
      toast({
        title: 'Success',
        description: 'Bill generated and units reset.',
      });
      fetchData(); // Refresh data
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to generate bill.',
        variant: 'destructive',
      });
    } finally {
      setBillingLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-24" />
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!customer) {
    return <div>Customer not found.</div>;
  }

  return (
    <div className="space-y-6 print:space-y-4">
      <div className="flex items-center justify-between print:hidden">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h2 className="text-3xl font-bold tracking-tight font-headline">
              {customer.customerName}
            </h2>
            <p className="text-muted-foreground">Account Details</p>
          </div>
        </div>
        <Button onClick={handlePrint}>
          <Printer className="mr-2 h-4 w-4" /> Print
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Customer Information</CardTitle>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-4 text-sm">
          <div>
            <strong>Account #:</strong> {customer.accountNumber}
          </div>
          <div>
            <strong>Phone:</strong> {customer.phoneNumber}
          </div>
          <div className="md:col-span-2">
            <strong>Address:</strong> {customer.address}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Current Billing Cycle</CardTitle>
            <CardDescription>Units consumed since last bill.</CardDescription>
          </div>
          <Button
            onClick={handleGenerateBill}
            disabled={billingLoading || customer.unitsConsumed === 0}
            style={{
              backgroundColor: 'var(--accent)',
              color: 'var(--accent-foreground)',
            }}
          >
            <FileText className="mr-2 h-4 w-4" />
            {billingLoading ? 'Generating...' : 'Generate Bill'}
          </Button>
        </CardHeader>
        <CardContent>
          <div className="flex items-baseline gap-4">
            <span className="text-4xl font-bold">{customer.unitsConsumed}</span>
            <span className="text-muted-foreground">units consumed</span>
          </div>
          {billingItem && (
            <p className="text-sm text-muted-foreground mt-2">
              Current rate: ${billingItem.price.toFixed(2)} per unit. Estimated
              Bill: ${(customer.unitsConsumed * billingItem.price).toFixed(2)}
            </p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Billing History</CardTitle>
          <CardDescription>Previous bills for this customer.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Bill ID</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Units Consumed</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bills.length > 0 ? (
                  bills
                    .sort(
                      (a, b) =>
                        new Date(b.date).getTime() - new Date(a.date).getTime()
                    )
                    .map((bill) => (
                      <TableRow key={bill.id}>
                        <TableCell className="font-mono">{bill.id}</TableCell>
                        <TableCell>
                          {new Date(bill.date).toLocaleDateString()}
                        </TableCell>
                        <TableCell>{bill.unitsConsumed}</TableCell>
                        <TableCell className="text-right">
                          ${bill.amount.toFixed(2)}
                        </TableCell>
                      </TableRow>
                    ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} className="h-24 text-center">
                      No billing history found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
