'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { CustomerForm } from '@/components/CustomerForm';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { authFetch } from '@/lib/authHandler';

export default function NewCustomerPage() {
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  const handleAddCustomer = async (formData: any) => {
    setLoading(true);
    try {
      // Generate a unique id (timestamp-based)
      const uniqueId = Date.now();

      // Build the customer JSON
      const customerData = {
        id: 0,
        customerName: formData.customerName,
        address: formData.address,
        phoneNumber: formData.phoneNumber,
        registrationDate:
          formData.registrationDate || new Date().toISOString().slice(0, 10),
        unitConsumed: 0,
        status: 'Active',
      };

      console.log(customerData);

      const res = await authFetch(
        'http://localhost:8080/api/v1/customer/save',
        {
          method: 'POST',
          body: JSON.stringify(customerData),
        }
      );
      if (!res.ok) {
        let errorMsg = 'Failed to create customer.';
        // Read the body as text once, then try to parse as JSON
        const errText = await res.text();
        try {
          const errData = JSON.parse(errText);
          errorMsg = errData.message || errorMsg;
        } catch {
          errorMsg = errText || errorMsg;
        }
        throw new Error(errorMsg);
      }
      toast({
        title: 'Success',
        description: 'Customer created successfully.',
      });
      router.push('/customers');
      router.refresh();
    } catch (error: any) {
      console.log(error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to create customer.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h2 className="text-3xl font-bold tracking-tight font-headline">
            Add New Customer
          </h2>
          <p className="text-muted-foreground">
            Fill out the form below to add a new customer.
          </p>
        </div>
      </div>
      <CustomerForm onSubmit={handleAddCustomer} loading={loading} />
    </div>
  );
}
