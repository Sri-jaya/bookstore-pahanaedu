'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Send, Bot, User, Loader2 } from 'lucide-react';
// import { helpQueryFlow } from '@/ai/flows/help';
import ReactMarkdown from 'react-markdown';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

interface Message {
  role: 'user' | 'bot';
  content: string;
}

export default function HelpPage() {
  const [question, setQuestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim() || loading) return;

    const userMessage: Message = { role: 'user', content: question };
    setMessages((prev) => [...prev, userMessage]);
    setQuestion('');
    setLoading(true);

    try {
      // const response = await run(helpQueryFlow, question);
      //   const botMessage: Message = { role: 'bot', content: response };
      //   setMessages((prev) => [...prev, botMessage]);
    } catch (error) {
      const errorMessage: Message = {
        role: 'bot',
        content: 'Sorry, I had trouble getting an answer. Please try again.',
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight font-headline">
          Help Center
        </h2>
        <p className="text-muted-foreground">
          Get help and instructions for using the system.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>AI Assistant</CardTitle>
            <CardDescription>
              Ask a question and our AI will help you.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col h-[60vh]">
            <div className="flex-grow overflow-y-auto p-4 border rounded-md mb-4 space-y-4 bg-muted/20">
              {messages.map((msg, index) => (
                <div
                  key={index}
                  className={`flex items-start gap-3 ${
                    msg.role === 'user' ? 'justify-end' : ''
                  }`}
                >
                  {msg.role === 'bot' && (
                    <Bot className="h-6 w-6 text-primary flex-shrink-0" />
                  )}
                  <div
                    className={`p-3 rounded-lg max-w-[80%] ${
                      msg.role === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-background'
                    }`}
                  >
                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                  </div>
                  {msg.role === 'user' && (
                    <User className="h-6 w-6 text-accent flex-shrink-0" />
                  )}
                </div>
              ))}
              {loading && (
                <div className="flex items-start gap-3">
                  <Bot className="h-6 w-6 text-primary" />
                  <div className="p-3 rounded-lg bg-background flex items-center">
                    <Loader2 className="h-5 w-5 animate-spin" />
                  </div>
                </div>
              )}
            </div>
            <form onSubmit={handleSubmit} className="flex gap-2">
              <Input
                placeholder="e.g., How do I add a customer?"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                disabled={loading}
              />
              <Button type="submit" disabled={loading || !question.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Frequently Asked Questions</CardTitle>
            <CardDescription>
              Quick answers to common questions.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>
                  How do I add a new customer?
                </AccordionTrigger>
                <AccordionContent>
                  Go to the "Customers" page from the sidebar. Click the "Add
                  Customer" button. Fill in the required details in the form and
                  click "Save Customer".
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger>How do I generate a bill?</AccordionTrigger>
                <AccordionContent>
                  Navigate to a specific customer's detail page by clicking
                  "View Details" on the customers list. On the detail page, you
                  will find a "Generate Bill" button under the "Current Billing
                  Cycle" section. Clicking this will calculate the bill based on
                  consumed units and add it to the billing history.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger>Can I edit an item's price?</AccordionTrigger>
                <AccordionContent>
                  Yes. Go to the "Items" page from the sidebar. Find the item
                  you want to edit and click the three-dots menu, then select
                  "Edit". You can update the price and other details on the
                  form. Note that price changes will only affect future bills.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-4">
                <AccordionTrigger>
                  How do I print a customer's details?
                </AccordionTrigger>
                <AccordionContent>
                  On the customer's detail page, there is a "Print" button at
                  the top right. Clicking it will open your browser's print
                  dialog to print the customer's information and billing
                  history.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
