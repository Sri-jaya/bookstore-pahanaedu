'use client';
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table } from '@/components/ui/table';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

import { authFetch } from '@/lib/authHandler';

export default function OrderScreen() {
  const [customers, setCustomers] = useState<any[]>([]);
  const [items, setItems] = useState<any[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<string>('');
  const [selectedItem, setSelectedItem] = useState<string>('');
  const [quantity, setQuantity] = useState<string>('1');
  const [cart, setCart] = useState<
    { itemId: number; name: string; price: number; quantity: number }[]
  >([]);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderDate, setOrderDate] = useState<Date | null>(null);
  const [loading, setLoading] = useState(false);

  // Load customers
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const res = await authFetch(
          'http://localhost:8080/api/v1/customer/getAll'
        );
        const data = await res.json();
        setCustomers(Array.isArray(data.data) ? data.data : []);
      } catch {
        setCustomers([]);
      }
    };
    fetchCustomers();
  }, []);

  // Load items
  useEffect(() => {
    const fetchItems = async () => {
      try {
        const res = await authFetch(
          'http://localhost:8080/api/v1/books/getAllBooks'
        );
        const data = await res.json();
        setItems(Array.isArray(data.data) ? data.data : []);
      } catch {
        setItems([]);
      }
    };
    fetchItems();
  }, []);

  // Add item to cart
  const handleAddToCart = () => {
    const itemId = Number(selectedItem);
    const qty = Number(quantity);
    if (!itemId || qty < 1) return;
    const item = items.find((i) => i.id === itemId);
    if (!item) return;
    setCart((prev) => {
      const existing = prev.find((c) => c.itemId === item.id);
      if (existing) {
        return prev.map((c) =>
          c.itemId === item.id ? { ...c, quantity: c.quantity + qty } : c
        );
      }
      return [
        ...prev,
        { itemId: item.id, name: item.name, price: item.price, quantity: qty },
      ];
    });
    setQuantity('1');
    setSelectedItem('');
  };

  // Remove item from cart
  const handleRemoveFromCart = (itemId: number) => {
    setCart((prev) => prev.filter((c) => c.itemId !== itemId));
  };

  // Calculate total
  const total = cart.reduce((sum, c) => sum + c.price * c.quantity, 0);

  const PrintableBill = ({ customer, cart, total, orderDate }: any) => {
    return (
      <div className="p-4 print-container">
        <h2 className="text-2xl font-bold mb-2">Bill</h2>
        <p>
          <strong>Customer:</strong> {customer?.customerName}
        </p>
        <p>
          <strong>Address:</strong> {customer?.address}
        </p>
        <p>
          <strong>Date:</strong> {orderDate?.toLocaleString()}
        </p>

        <table className="table-auto w-full border border-collapse my-4">
          <thead>
            <tr>
              <th className="border px-2 py-1">Item</th>
              <th className="border px-2 py-1">Qty</th>
              <th className="border px-2 py-1">Price</th>
              <th className="border px-2 py-1">Total</th>
            </tr>
          </thead>
          <tbody>
            {cart.map((item: any, idx: number) => (
              <tr key={idx}>
                <td className="border px-2 py-1">{item.name}</td>
                <td className="border px-2 py-1">{item.quantity}</td>
                <td className="border px-2 py-1">Rs. {item.price}</td>
                <td className="border px-2 py-1">
                  Rs. {item.price * item.quantity}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <h3 className="text-right font-bold text-lg">Total: Rs. {total}</h3>
      </div>
    );
  };

  const printRef = React.useRef<HTMLDivElement>(null);

  // Print handler
  const handlePrint = () => {
    if (!selectedCustomer || !orderDate) return;
    // Open a new window with the bill content and print it
    const printContents = printRef.current?.innerHTML;
    if (printContents) {
      const printWindow = window.open('', '', 'height=600,width=800');
      if (printWindow) {
        printWindow.document.write('<html><head><title>Bill</title>');
        printWindow.document.write(
          '<style>body{font-family:sans-serif;} .print-container{padding:24px;} table{width:100%;border-collapse:collapse;} th,td{border:1px solid #ccc;padding:8px;text-align:left;} </style>'
        );
        printWindow.document.write('</head><body>');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 500);
      }
    }
  };

  // Place order and save to backend
  const handlePlaceOrder = async () => {
    if (!selectedCustomer || cart.length === 0) return;
    setLoading(true);
    setOrderPlaced(false);
    setOrderDate(new Date());

    // Prepare order payload
    const billPayload = {
      id: 0,
      billDate: new Date().toISOString().slice(0, 10),
      customerId: Number(selectedCustomer),
      totalAmount: total,
      status: 'Active',
      bookDTOS: cart.map((c) => ({
        id: c.itemId,
        price: c.price,
        stockQty: c.quantity,
      })),
    };

    try {
      const res = await authFetch('http://localhost:8080/api/v1/bill/save', {
        method: 'POST',
        body: JSON.stringify(billPayload),
      });
      if (!res.ok) throw new Error('Failed to save bill');
      setOrderPlaced(true);
      setTimeout(() => {
        console.log('🖨️ Printing HTML:', printRef.current?.innerHTML);

        handlePrint();
        setLoading(false);
      }, 1000);
    } catch (error: any) {
      alert(error.message || 'Failed to place order');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="max-w-3xl mx-auto mt-10 p-8 shadow-lg bg-white">
      <h2 className="text-2xl font-bold mb-6 text-center">
        Place Order & Print Bill
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <div>
          <div className="mb-6">
            <Label> Select Customer</Label>
            <Select
              value={selectedCustomer}
              onValueChange={setSelectedCustomer}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select customer" />
              </SelectTrigger>
              <SelectContent>
                {customers.map((c) => (
                  <SelectItem key={c.id} value={c.id.toString()}>
                    {c.customerName} ({c.address})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {selectedCustomer && (
            <div className="mb-6 p-3 bg-gray-50 rounded border">
              <div>
                <span className="font-semibold">Name:</span>{' '}
                {
                  customers.find((c) => c.id === Number(selectedCustomer))
                    ?.customerName
                }
              </div>
              <div>
                <span className="font-semibold">Address:</span>{' '}
                {
                  customers.find((c) => c.id === Number(selectedCustomer))
                    ?.address
                }
              </div>
            </div>
          )}
        </div>
        <div>
          <div className="mb-6">
            <Label> Select Item</Label>
            <div className="flex gap-2">
              <Select value={selectedItem} onValueChange={setSelectedItem}>
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Select item" />
                </SelectTrigger>
                <SelectContent>
                  {items.map((i) => (
                    <SelectItem key={i.id} value={i.id.toString()}>
                      {i.name} (Rs. {i.price})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                type="number"
                min={1}
                value={quantity}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setQuantity(e.target.value)
                }
                style={{ width: 80 }}
              />
              <Button onClick={handleAddToCart} disabled={!selectedItem}>
                Add
              </Button>
            </div>
          </div>
        </div>
      </div>
      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-2">Cart</h3>
        <Table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Qty</th>
              <th>Price</th>
              <th>Total</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {cart.length === 0 ? (
              <tr>
                <td colSpan={5} className="text-center text-gray-400 py-4">
                  Cart is empty
                </td>
              </tr>
            ) : (
              cart.map((c) => (
                <tr key={c.itemId}>
                  <td>{c.name}</td>
                  <td>{c.quantity}</td>
                  <td>Rs. {c.price}</td>
                  <td>Rs. {c.price * c.quantity}</td>
                  <td>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleRemoveFromCart(c.itemId)}
                    >
                      Remove
                    </Button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </Table>
      </div>
      <div style={{ display: 'none' }}>
        <div ref={printRef}>
          <PrintableBill
            customer={customers.find((c) => c.id === Number(selectedCustomer))}
            cart={cart}
            total={total}
            orderDate={orderDate}
          />
        </div>
      </div>
      <div className="flex flex-col md:flex-row justify-between items-center mt-4 gap-4">
        <span className="font-bold text-xl">Total: Rs. {total}</span>
        <Button
          onClick={handlePlaceOrder}
          disabled={!selectedCustomer || cart.length === 0 || loading}
          className="px-8 py-2"
        >
          {loading ? 'Placing Order...' : 'Place Order & Print Bill'}
        </Button>
      </div>
      {orderPlaced && (
        <div className="mt-6 text-green-600 text-center text-lg">
          Order placed! Bill is downloading...
        </div>
      )}
    </Card>
  );
}
