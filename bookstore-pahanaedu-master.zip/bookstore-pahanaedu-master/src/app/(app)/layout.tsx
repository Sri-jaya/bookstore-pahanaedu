'use client';

import React from 'react';
import { usePathname } from 'next/navigation';
// import { useAuth } from '@/hooks/useAuth';
import { AppLogo } from '@/components/AppLogo';
import {
  Home,
  Users,
  Package,
  HelpCircle,
  LogOut,
  Paperclip,
} from 'lucide-react';
import Link from 'next/link';
import {
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
  SidebarProvider,
  SidebarInset,
} from '@/components/ui/sidebar';

function ProtectedLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  // You can place this utility function in a common file or inside your sidebar/menu component

  function logout() {
    // Remove cookies by setting expiry in the past
    document.cookie = 'auth=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
    document.cookie =
      'refreshToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
    // Optionally, redirect to login page
    window.location.href = '/login';
  }

  const navItems = [
    { href: '/', label: 'Dashboard', icon: Home },
    { href: '/customers', label: 'Customers', icon: Users },
    { href: '/items', label: 'Items', icon: Package },
    { href: '/help', label: 'Help', icon: HelpCircle },
    { href: '/billing', label: 'Billing', icon: Paperclip },
  ];

  return (
    <SidebarProvider>
      <Sidebar>
        <SidebarHeader>
          <AppLogo />
        </SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            {navItems.map((item) => (
              <SidebarMenuItem key={item.href}>
                <SidebarMenuButton
                  asChild
                  isActive={pathname === item.href}
                  tooltip={item.label}
                >
                  <Link href={item.href}>
                    <item.icon />
                    <span>{item.label}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter>
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton onClick={logout} tooltip="Logout">
                <LogOut />
                <span>Logout</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset>
        <div className="p-4 md:p-6">{children}</div>
      </SidebarInset>
    </SidebarProvider>
  );
}

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return <ProtectedLayout>{children}</ProtectedLayout>;
}
