'use client';
import React, { useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import { authFetch } from '@/lib/authHandler';

const icons = {
  customers: (
    <svg
      className="w-8 h-8 text-blue-500"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      viewBox="0 0 24 24"
    >
      <path d="M17 20h5v-2a4 4 0 0 0-3-3.87M9 20H4v-2a4 4 0 0 1 3-3.87m9-4.13a4 4 0 1 0-8 0 4 4 0 0 0 8 0z" />
    </svg>
  ),
  items: (
    <svg
      className="w-8 h-8 text-green-500"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      viewBox="0 0 24 24"
    >
      <rect x="3" y="4" width="18" height="16" rx="2" />
      <path d="M16 2v4M8 2v4M3 10h18" />
    </svg>
  ),
  orders: (
    <svg
      className="w-8 h-8 text-orange-500"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      viewBox="0 0 24 24"
    >
      <path d="M3 7h18M6 7V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v2M6 7v10a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7" />
    </svg>
  ),
};

export default function Dashboard() {
  const [counts, setCounts] = useState({
    customers: 0,
    items: 0,
    orders: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchCounts() {
      try {
        const [customersRes, itemsRes, ordersRes] = await Promise.all([
          authFetch('http://localhost:8080/api/v1/customer/count'),
          authFetch('http://localhost:8080/api/v1/books/count'),
          authFetch('http://localhost:8080/api/v1/bill/count'),
        ]);
        const customersData = await customersRes.json();
        const itemsData = await itemsRes.json();
        const ordersData = await ordersRes.json();

        setCounts({
          customers: customersData.data ?? 0,
          items: itemsData.data ?? 0,
          orders: ordersData.data ?? 0,
        });
      } catch {
        setCounts({ customers: 0, items: 0, orders: 0 });
      } finally {
        setLoading(false);
      }
    }
    fetchCounts();
  }, []);

  const metrics = [
    {
      label: 'Total Customers',
      value: counts.customers,
      icon: icons.customers,
    },
    {
      label: 'Total Items',
      value: counts.items,
      icon: icons.items,
    },
    {
      label: 'Total Orders',
      value: counts.orders,
      icon: icons.orders,
    },
  ];

  return (
    <div className="max-w-5xl mx-auto mt-10 px-4">
      <h1 className="text-3xl font-bold mb-6 text-center">
        Book Shop Dashboard
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        {metrics.map((metric) => (
          <Card
            key={metric.label}
            className="flex flex-col items-center p-6 shadow-md"
          >
            <div className="mb-2">{metric.icon}</div>
            <div className="text-2xl font-bold">
              {loading ? '...' : metric.value}
            </div>
            <div className="text-gray-600">{metric.label}</div>
          </Card>
        ))}
      </div>
      <Card className="p-6 shadow-md">
        <h2 className="text-xl font-semibold mb-2">
          Welcome to Pahana Book Shop!
        </h2>
        <p className="text-gray-700 mb-2">
          Manage your customers, items, and orders efficiently. Use the
          navigation to place new orders, view bills, and keep track of your
          inventory.
        </p>
        <ul className="list-disc pl-6 text-gray-700">
          <li>View and manage all customers and their orders.</li>
          <li>Track your inventory and add new items easily.</li>
          <li>Generate and download bills for every order placed.</li>
        </ul>
      </Card>
    </div>
  );
}
