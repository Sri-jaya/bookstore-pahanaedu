'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { ItemForm } from '@/components/ItemForm';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { authFetch } from '@/lib/authHandler';

export default function NewItemPage() {
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  const handleAddItem = async (data: any) => {
    setLoading(true);
    try {
      const res = await authFetch('http://localhost:8080/api/v1/books/save', {
        method: 'POST',
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        let errorMsg = 'Failed to create item.';
        const errText = await res.text();
        try {
          const errData = JSON.parse(errText);
          errorMsg = errData.message || errorMsg;
        } catch {
          errorMsg = errText || errorMsg;
        }
        throw new Error(errorMsg);
      }
      toast({
        title: 'Success',
        description: 'Item created successfully.',
      });
      router.push('/items');
      router.refresh();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create item.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h2 className="text-3xl font-bold tracking-tight font-headline">
            Add New Item
          </h2>
          <p className="text-muted-foreground">
            Fill out the form below to add a new billable item.
          </p>
        </div>
      </div>
      <ItemForm onSubmit={handleAddItem} loading={loading} />
    </div>
  );
}
