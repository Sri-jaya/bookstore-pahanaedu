'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { ItemForm } from '@/components/ItemForm';
import type { Item } from '@/types';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { authFetch } from '@/lib/authHandler';

export default function EditItemPage() {
  const [item, setItem] = useState<Item | null>(null);
  const [loading, setLoading] = useState(false);
  const [pageLoading, setPageLoading] = useState(true);
  const router = useRouter();
  const params = useParams();
  const { toast } = useToast();
  const id = params.id as string;

  // Fetch item when page loads
  useEffect(() => {
    const fetchItem = async () => {
      try {
        const res = await authFetch(
          `http://localhost:8080/api/v1/books?id=${id}`
        );
        if (!res.ok) throw new Error('Failed to fetch item');
        const data = await res.json();
        setItem(data.data);
      } catch (error: any) {
        toast({
          title: 'Error',
          description: error.message || 'Failed to fetch item.',
          variant: 'destructive',
        });
      } finally {
        setPageLoading(false);
      }
    };
    if (id) fetchItem();
  }, [id, toast]);

  const updateItem = async (id: string, data: any) => {
    // Ensure id is included in the body
    const updatedData = { ...data, id };
    console.log(updatedData);
    const res = await authFetch(`http://localhost:8080/api/v1/books/update`, {
      method: 'PUT',
      body: JSON.stringify(updatedData),
    });
    if (!res.ok) {
      let errorMsg = 'Failed to update item.';
      const errText = await res.text();
      try {
        const errData = JSON.parse(errText);
        errorMsg = errData.message || errorMsg;
      } catch {
        errorMsg = errText || errorMsg;
      }
      throw new Error(errorMsg);
    }
  };

  const handleUpdateItem = async (data: any) => {
    setLoading(true);
    try {
      await updateItem(id, data);
      toast({
        title: 'Success',
        description: 'Item updated successfully.',
      });
      router.push('/items');
      router.refresh();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update item.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (pageLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Skeleton className="h-10 w-10" />
          <div className="space-y-2">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-5 w-80" />
          </div>
        </div>
        <Skeleton className="h-[400px] w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h2 className="text-3xl font-bold tracking-tight font-headline">
            Edit Item
          </h2>
          <p className="text-muted-foreground">Editing item: {item?.name}.</p>
        </div>
      </div>
      <ItemForm
        initialData={item}
        onSubmit={handleUpdateItem}
        loading={loading}
      />
    </div>
  );
}
