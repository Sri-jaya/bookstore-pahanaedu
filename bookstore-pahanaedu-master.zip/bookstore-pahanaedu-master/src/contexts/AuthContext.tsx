"use client";

import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import type { User } from '@/types';

interface AuthContextType {
  user: User | null;
  token: string | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (name: string, email: string, pass: string) => Promise<void>;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user database
const users: (User & {password: string})[] = [
    { id: '1', email: 'user@example.com', name: 'Test User', password: 'password123' }
];

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    try {
        const storedToken = localStorage.getItem('authToken');
        const storedUser = localStorage.getItem('user');
        if (storedToken && storedUser) {
            setToken(storedToken);
            setUser(JSON.parse(storedUser));
        }
    } catch (error) {
        console.error("Could not parse user from localStorage", error);
        localStorage.removeItem('authToken');
        localStorage.removeItem('user');
    }
    setLoading(false);
  }, []);

  const login = async (email: string, pass: string) => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    const foundUser = users.find(u => u.email === email && u.password === pass);

    if (foundUser) {
      const { password, ...userToStore } = foundUser;
      const mockToken = `mock-jwt-for-${userToStore.id}`;
      setUser(userToStore);
      setToken(mockToken);
      localStorage.setItem('authToken', mockToken);
      localStorage.setItem('user', JSON.stringify(userToStore));
      router.push('/');
    } else {
      setLoading(false);
      throw new Error('Invalid email or password');
    }
    setLoading(false);
  };

  const register = async (name: string, email: string, pass: string) => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    if (users.some(u => u.email === email)) {
        setLoading(false);
        throw new Error('User with this email already exists');
    }

    const newUser = { id: String(users.length + 1), name, email, password: pass };
    users.push(newUser);
    
    const { password, ...userToStore } = newUser;
    const mockToken = `mock-jwt-for-${userToStore.id}`;
    setUser(userToStore);
    setToken(mockToken);
    localStorage.setItem('authToken', mockToken);
    localStorage.setItem('user', JSON.stringify(userToStore));
    router.push('/');
    setLoading(false);
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
    router.push('/login');
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
