import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  if (
    request.nextUrl.pathname.startsWith('/dashboard') ||
    request.nextUrl.pathname.startsWith('/billing') ||
    request.nextUrl.pathname.startsWith('/customers') ||
    request.nextUrl.pathname.startsWith('/items') ||
    request.nextUrl.pathname.startsWith('/help')
  ) {
    // Example: Check for a cookie (e.g., 'auth')
    const authCookie = request.cookies.get('auth');
    if (!authCookie) {
      // Redirect to home or login page
      return NextResponse.redirect(new URL('/login', request.url));
    }
  }

  if (
    request.nextUrl.pathname.startsWith('/login') ||
    request.nextUrl.pathname.startsWith('/signup')
  ) {
    const authCookie = request.cookies.get('auth');
    if (authCookie) {
      const referer = request.headers.get('referer');
      if (
        referer &&
        (referer.includes('/login') || referer.includes('/signup'))
      ) {
        return NextResponse.redirect(new URL('/dashboard', request.url));
      } else if (referer) {
        return NextResponse.redirect(referer);
      } else {
        return NextResponse.redirect(new URL('/dashboard', request.url));
      }
    }
  }
  return NextResponse.next();
}

// Specify matcher for /write
export const config = {
  matcher: [
    '/dashboard',
    '/login',
    '/signup',
    '/billing',
    '/customers',
    '/items',
    '/help',
  ],
};
