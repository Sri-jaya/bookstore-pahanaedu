export interface User {
  id: string;
  email: string;
  name: string;
}

export interface Customer {
  id: string;
  accountNumber: string;
  customerName: string;
  address: string;
  phoneNumber: string;
  unitsConsumed: number;
  status: string;
  registrationDate: string;
}

export interface Item {
  id: string;
  name: string;
  description: string;
  stockQty: number;
  category: string;
  price: number; // Price per unit
}

export interface Bill {
  id: string;
  customerId: string;
  date: string;
  unitsConsumed: number;
  amount: number;
}
