function getCookie(name: string) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop()?.split(';').shift();
  return '';
}

export async function authFetch(url: string, options: RequestInit = {}) {
  const jwt = getCookie('auth');
  const headers = {
    ...(options.headers || {}),
    Authorization: `Bearer ${jwt}`,
    'Content-Type': 'application/json',
  };

  // let body = options.body;
  // if (body && typeof body === 'object' && !(body instanceof FormData)) {
  //   body = JSON.stringify(body);
  // }

  return fetch(url, {
    ...options,
    headers,
    // body
  });
}
