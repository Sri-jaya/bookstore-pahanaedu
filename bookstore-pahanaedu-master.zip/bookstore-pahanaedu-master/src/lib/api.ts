"use client";

import type { Customer, Item, Bill } from "@/types";

const getFromStorage = <T>(key: string, defaultValue: T): T => {
    if (typeof window === 'undefined') return defaultValue;
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
};

const saveToStorage = <T>(key: string, value: T) => {
    if (typeof window !== 'undefined') {
        localStorage.setItem(key, JSON.stringify(value));
    }
};

// Initial Data
const initialCustomers: Customer[] = [
    { id: '1', accountNumber: 'CUST-001', name: 'Alice Johnson', address: '123 Maple St', phoneNumber: '555-0101', unitsConsumed: 150 },
    { id: '2', accountNumber: 'CUST-002', name: 'Bob Smith', address: '456 Oak Ave', phoneNumber: '555-0102', unitsConsumed: 200 },
    { id: '3', accountNumber: 'CUST-003', name: 'Charlie Brown', address: '789 Pine Ln', phoneNumber: '555-0103', unitsConsumed: 75 },
];

const initialItems: Item[] = [
    { id: '1', name: 'Book Unit', description: 'Standard unit for book consumption billing.', price: 1.25 },
];

const initialBills: Bill[] = [
    { id: '1', customerId: '1', date: '2023-10-28', unitsConsumed: 140, amount: 175},
    { id: '2', customerId: '1', date: '2023-11-28', unitsConsumed: 150, amount: 187.5},
];

// Initialize storage if empty
if (typeof window !== 'undefined' && !localStorage.getItem('customers')) {
    saveToStorage('customers', initialCustomers);
}
if (typeof window !== 'undefined' && !localStorage.getItem('items')) {
    saveToStorage('items', initialItems);
}
if (typeof window !== 'undefined' && !localStorage.getItem('bills')) {
    saveToStorage('bills', initialBills);
}


// --- Customer API ---
export const getCustomers = async (): Promise<Customer[]> => {
    return new Promise(resolve => setTimeout(() => resolve(getFromStorage('customers', [])), 500));
};

export const getCustomerById = async (id: string): Promise<Customer | undefined> => {
    const customers = getFromStorage<Customer[]>('customers', []);
    return new Promise(resolve => setTimeout(() => resolve(customers.find(c => c.id === id)), 300));
};

export const addCustomer = async (customerData: Omit<Customer, 'id'>): Promise<Customer> => {
    const customers = getFromStorage<Customer[]>('customers', []);
    const newCustomer: Customer = { ...customerData, id: String(Date.now()) };
    const updatedCustomers = [...customers, newCustomer];
    saveToStorage('customers', updatedCustomers);
    return new Promise(resolve => setTimeout(() => resolve(newCustomer), 300));
};

export const updateCustomer = async (id: string, customerData: Partial<Customer>): Promise<Customer> => {
    const customers = getFromStorage<Customer[]>('customers', []);
    const index = customers.findIndex(c => c.id === id);
    if (index === -1) throw new Error("Customer not found");
    const updatedCustomer = { ...customers[index], ...customerData };
    customers[index] = updatedCustomer;
    saveToStorage('customers', customers);
    return new Promise(resolve => setTimeout(() => resolve(updatedCustomer), 300));
};

export const deleteCustomer = async (id: string): Promise<void> => {
    const customers = getFromStorage<Customer[]>('customers', []);
    const updatedCustomers = customers.filter(c => c.id !== id);
    saveToStorage('customers', updatedCustomers);
    return new Promise(resolve => setTimeout(resolve, 300));
};


// --- Item API ---
export const getItems = async (): Promise<Item[]> => {
    return new Promise(resolve => setTimeout(() => resolve(getFromStorage('items', [])), 500));
};

export const getItemById = async (id: string): Promise<Item | undefined> => {
    const items = getFromStorage<Item[]>('items', []);
    return new Promise(resolve => setTimeout(() => resolve(items.find(i => i.id === id)), 300));
};

export const addItem = async (itemData: Omit<Item, 'id'>): Promise<Item> => {
    const items = getFromStorage<Item[]>('items', []);
    const newItem: Item = { ...itemData, id: String(Date.now()) };
    const updatedItems = [...items, newItem];
    saveToStorage('items', updatedItems);
    return new Promise(resolve => setTimeout(() => resolve(newItem), 300));
};

export const updateItem = async (id: string, itemData: Partial<Item>): Promise<Item> => {
    const items = getFromStorage<Item[]>('items', []);
    const index = items.findIndex(i => i.id === id);
    if (index === -1) throw new Error("Item not found");
    const updatedItem = { ...items[index], ...itemData };
    items[index] = updatedItem;
    saveToStorage('items', items);
    return new Promise(resolve => setTimeout(() => resolve(updatedItem), 300));
};

export const deleteItem = async (id: string): Promise<void> => {
    const items = getFromStorage<Item[]>('items', []);
    const updatedItems = items.filter(i => i.id !== id);
    saveToStorage('items', updatedItems);
    return new Promise(resolve => setTimeout(resolve, 300));
};

// --- Billing API ---
export const getBillsForCustomer = async(customerId: string): Promise<Bill[]> => {
    const bills = getFromStorage<Bill[]>('bills', []);
    return new Promise(resolve => setTimeout(() => resolve(bills.filter(b => b.customerId === customerId)), 300));
}

export const calculateAndSaveBill = async (customerId: string): Promise<Bill> => {
    const customer = await getCustomerById(customerId);
    if (!customer) throw new Error('Customer not found for billing');
    
    const items = await getItems();
    const billingItem = items[0]; // Assuming one item for unit price
    if (!billingItem) throw new Error('Billing item not configured');

    const amount = customer.unitsConsumed * billingItem.price;

    const newBill: Bill = {
        id: String(Date.now()),
        customerId,
        date: new Date().toISOString().split('T')[0],
        unitsConsumed: customer.unitsConsumed,
        amount,
    };

    const allBills = getFromStorage<Bill[]>('bills', []);
    allBills.push(newBill);
    saveToStorage('bills', allBills);

    // Reset units consumed after billing
    await updateCustomer(customerId, { unitsConsumed: 0 });

    return new Promise(resolve => setTimeout(() => resolve(newBill), 300));
}
